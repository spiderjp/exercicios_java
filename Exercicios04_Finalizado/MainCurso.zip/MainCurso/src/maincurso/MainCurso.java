/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maincurso;

import javax.swing.JOptionPane;

/**
 *
 * @author jotap
 */
public class MainCurso {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
                Curso c1 = new Curso(){};
                       
                
                Curso c2;
                
                c2 = new Curso("Análise e Desenvolvimento de Sistemas", 80, "A", 500);
            
                /*
                
                c1.nome = JOptionPane.showInputDialog("Digite o nome do Curso: ");
                c1.quantialunos = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de alunos: "));
                c1.turma = JOptionPane.showInputDialog("Digite a turma: ");
                c1.mensalidade = Float.parseFloat(JOptionPane.showInputDialog("Digite o valor da mensalidade: "));
                
                Ou  */
                
                c1.cadastraCurso();
                c1.imprimiDados();
            
                JOptionPane.showMessageDialog(null, "Nome: " + c1.nome + "\nQuantidade de Alunos: " + c1.quantialunos + "\nTurma: " + c1.turma + "\nMensalidade: " +
                       c1.mensalidade);
                
                System.out.println(c2);
                
                
    }
    
}
