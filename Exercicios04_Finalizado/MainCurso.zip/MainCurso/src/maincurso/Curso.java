/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maincurso;

import javax.swing.JOptionPane;

/**
 *
 * @author jotap
 */
public class Curso {
    
    String nome;
    int quantialunos;
    String turma;
    float mensalidade;
    
    
    Curso(){};
    
    Curso(String n, int q, String t, float m){
    
    this.nome = n;    
    this.quantialunos = q;
    this.turma = t;
    this.mensalidade = m;

    
    
    
    };
    
    void cadastraCurso(){
    
               nome = JOptionPane.showInputDialog(null, "Digite o nome do Curso: ");
               quantialunos = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a quantidade de alunos: "));
               turma = JOptionPane.showInputDialog(null, "Digite a turma: ");
               mensalidade = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor da mensalidade: "));

            
    };
    
    void imprimiDados(){
    
    System.out.println("Nome do Curso: " + nome + "\nQuantidade de Alunos: " + quantialunos + "\nTurma: " + turma + "\nMensalidade: " + mensalidade);
            
    };
    
    float calculaTotalMensalidade(){
       
        return (quantialunos * mensalidade);
       
    };
}
