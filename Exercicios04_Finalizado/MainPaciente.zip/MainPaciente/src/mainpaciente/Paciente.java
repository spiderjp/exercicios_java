/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpaciente;

import javax.swing.JOptionPane;


/**
 *
 * @author jotap
 */
public class Paciente {
    String nome;
    String rg;
    String endereco;
    String telefone;
    int dataNascimento;
    String profissao;
    
    Paciente(){};
    
    Paciente(String n){
    
    this.nome = n;
    
    };
    
    void cadastraDados(){
    
        nome = JOptionPane.showInputDialog("Digite seu nome: ");
        rg = JOptionPane.showInputDialog("Digite seu RG: ");
        endereco = JOptionPane.showInputDialog("Digite seu endereço: ");
        dataNascimento = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do seu aniversário: "));
        telefone = JOptionPane.showInputDialog("Digite seu telefone: ");
        profissao = JOptionPane.showInputDialog("Digite sua profissão: ");
    
    };
    
    void imprimeDados(){
    
    System.out.println("Nome: " + nome + "\nRG: " + rg + "\nEndereço: " + endereco + "\nTelefone: " + telefone + "\nDataNascimento: " + dataNascimento + 
            "\nProfissão: " + profissao);
    
    };
    
    int calculaldade(int anoatual){
    
    
        anoatual = 2020;
        return (anoatual - dataNascimento);
    };
}
