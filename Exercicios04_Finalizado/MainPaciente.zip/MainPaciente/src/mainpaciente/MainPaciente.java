/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpaciente;

import javax.swing.JOptionPane;

/**
 *
 * @author jotap
 */
public class MainPaciente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Paciente p1 = new Paciente();
        
        /*
        
        p1.nome = JOptionPane.showInputDialog("Digite seu nome: ");
        p1.rg = JOptionPane.showInputDialog("Digite seu RG: ");
        p1.endereco = JOptionPane.showInputDialog("Digite seu endereço: ");
        p1.dataNascimento = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do seu aniversário: "));
        p1.telefone = JOptionPane.showInputDialog("Digite seu telefone: ");
        p1.profissao = JOptionPane.showInputDialog("Digite sua profissão: ");
        
         Ou */
        
        p1.cadastraDados();
        p1.imprimeDados();
        
        Paciente p2 = new Paciente("João Pedro Ferreira");

        JOptionPane.showMessageDialog(null, "Nome: " + p1.nome + "\nRG: " + p1.rg + "\nEndereço: " + p1.endereco + "\ndataNascimento: " + p1.dataNascimento +
                "\nTelefone: " + p1.telefone + "\nProfissão: " + p1.profissao);
        
         System.out.println(p2);
    }
    
}
